﻿namespace ClassLibraryHotel
{
    interface IValidatable
    {
        bool IsValid { get; }
    }
}
