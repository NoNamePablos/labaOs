﻿namespace ClassLibraryHotel.Serialization
{
    public enum SerializeType
    {
        XML,
        JSON,
        Binary
    }
}
